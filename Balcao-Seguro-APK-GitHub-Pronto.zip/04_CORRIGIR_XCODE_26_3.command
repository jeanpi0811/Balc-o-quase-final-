#!/bin/bash
# Corrige o erro "'RuntimeScheduler' cannot be annotated with either
# SWIFT_RETURNS_RETAINED..." no Xcode 26.3 e reconstrói os Pods.
set -e
cd "$(dirname "$0")"

echo "==> 1/4 Fechando o Xcode"
osascript -e 'tell application "Xcode" to quit' 2>/dev/null || true
sleep 2

echo "==> 2/4 Instalando dependências e aplicando a correção"
npm install
node scripts/patch-expo-modules-jsi.js

echo "==> 3/4 Limpando caches de build"
rm -rf ios/build/Build ios/build/ModuleCache 2>/dev/null || true
rm -rf ~/Library/Developer/Xcode/DerivedData/BalcoSeguro-* 2>/dev/null || true

echo "==> 4/4 Reinstalando Pods"
cd ios
pod install
cd ..

echo "Pronto. Abrindo o Xcode..."
open ios/BalcoSeguro.xcworkspace

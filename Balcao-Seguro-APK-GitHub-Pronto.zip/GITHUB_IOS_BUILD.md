# Balcão Seguro — CI iOS no GitHub Actions

Workflow: `.github/workflows/ios.yml`

O workflow usa um runner macOS 26, instala Node/dependências e CocoaPods, valida TypeScript,
compila o workspace Xcode em Release e gera um XCArchive e um IPA **não assinado**.

O IPA unsigned serve para verificar a compilação/empacotamento. Para TestFlight/App Store ou
instalação em aparelho físico, é necessário assinar o app com certificados e provisioning profile
da Apple Developer.

O projeto contém o diretório `ios/` nativo e o workflow **não executa `expo prebuild --clean`**,
evitando regenerar e sobrescrever o projeto Xcode versionado.

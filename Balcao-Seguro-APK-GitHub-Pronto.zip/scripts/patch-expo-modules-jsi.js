#!/usr/bin/env node
/**
 * Correção para Xcode 26.3 (Swift 6.2.x) + Expo SDK 57.
 *
 * Erro:
 *   'RuntimeScheduler' cannot be annotated with either SWIFT_RETURNS_RETAINED
 *   or SWIFT_RETURNS_UNRETAINED because it is not returning a
 *   SWIFT_SHARED_REFERENCE type
 *
 * Causa: o header RuntimeScheduler.h do pacote expo-modules-jsi anota os dois
 * construtores com SWIFT_RETURNS_RETAINED. O compilador do Xcode 26.3 rejeita
 * isso. A anotação não tem efeito em construtor; a posse do objeto continua
 * definida pelo SWIFT_SHARED_REFERENCE(...) da classe, que NÃO é alterado.
 *
 * Segundo erro (JavaScriptRuntime.swift, Swift 6.2):
 *   sending 'resultPtr' / 'thisPtr' / 'argumentsPtr' risks causing data races
 * Causa: ponteiros crus capturados via "nonisolated(unsafe) let" dentro de
 * closures do JavaScriptActor. Correção: embrulhar cada ponteiro numa struct
 * Sendable (@unchecked) e usar .value dentro do closure. Custo zero em runtime;
 * os ponteiros são usados de forma síncrona (assumeIsolated), como o código
 * original já assumia.
 *
 * O script é idempotente (pode rodar quantas vezes quiser) e roda
 * automaticamente após "npm install" (script "postinstall").
 * Pode ser removido ao atualizar para Xcode 26.4+ / nova versão do pacote.
 */
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const pkgDir = path.join(root, 'node_modules', 'expo-modules-jsi');

function findHeaders(dir, out = []) {
  if (!fs.existsSync(dir)) return out;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (entry.name === 'node_modules' || entry.name === 'build') continue;
      findHeaders(full, out);
    } else if (entry.name === 'RuntimeScheduler.h') {
      out.push(full);
    }
  }
  return out;
}

if (!fs.existsSync(pkgDir)) {
  console.log('[patch-expo-modules-jsi] expo-modules-jsi não instalado; nada a fazer.');
  process.exit(0);
}

const headers = findHeaders(pkgDir);
if (headers.length === 0) {
  console.log('[patch-expo-modules-jsi] RuntimeScheduler.h não encontrado; pulando esse patch.');
}

// Remove SWIFT_RETURNS_RETAINED / SWIFT_RETURNS_UNRETAINED apenas quando aparece
// imediatamente antes de um construtor "RuntimeScheduler(".
const ctorAnnotation = /\bSWIFT_RETURNS_(?:UN)?RETAINED\s+(?=RuntimeScheduler\s*\()/g;

let changed = 0;
for (const file of headers) {
  const original = fs.readFileSync(file, 'utf8');
  const patched = original.replace(ctorAnnotation, '');
  if (patched !== original) {
    fs.writeFileSync(file, patched, 'utf8');
    changed++;
    console.log('[patch-expo-modules-jsi] corrigido: ' + path.relative(root, file));
  } else {
    console.log('[patch-expo-modules-jsi] já estava correto: ' + path.relative(root, file));
  }
}

// ---------------------------------------------------------------------------
// Patch 2: JavaScriptRuntime.swift
// ---------------------------------------------------------------------------
function findFile(dir, name, out = []) {
  if (!fs.existsSync(dir)) return out;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (entry.name === 'node_modules' || entry.name === 'build') continue;
      findFile(full, name, out);
    } else if (entry.name === name) {
      out.push(full);
    }
  }
  return out;
}

const BOX_MARK = 'SendablePointerBox';
const BOX_DEF = [
  '',
  '// Patch Xcode 26.3 / Swift 6.2: embrulha ponteiros crus para atravessar closures do JavaScriptActor.',
  'private struct ' + BOX_MARK + '<Pointee>: @unchecked Sendable {',
  '  let value: Pointee',
  '  init(_ value: Pointee) { self.value = value }',
  '}',
  '',
].join('\n');

const DECL = /^(\s*)nonisolated\(unsafe\) let (resultPtr|thisPtr|argumentsPtr) = \2\s*$/;

function patchRuntimeSwift(text) {
  if (text.includes(BOX_MARK)) return { text, status: 'already' };
  const lines = text.split('\n');
  let i = 0;
  let groups = 0;
  while (i < lines.length) {
    const m = lines[i].match(DECL);
    if (!m) { i++; continue; }
    const indent = m[1].length;
    // bloco contíguo de declarações nonisolated(unsafe) let ...Ptr = ...Ptr
    const names = [];
    let j = i;
    while (j < lines.length) {
      const mm = lines[j].match(DECL);
      if (mm) { names.push(mm[2]); lines[j] = mm[1] + 'let ' + mm[2] + 'Box = ' + BOX_MARK + '(' + mm[2] + ')'; j++; }
      else if (lines[j].trim() === '') { j++; }
      else break;
    }
    // fim da função: primeira linha "}" com indentação menor que o corpo
    let end = j;
    while (end < lines.length) {
      const l = lines[end];
      if (/^\s*\}\s*$/.test(l) && l.match(/^\s*/)[0].length < indent) break;
      end++;
    }
    for (let k = j; k < end; k++) {
      let l = lines[k];
      for (const n of names) {
        l = l
          .replace(new RegExp('(to:\\s*)' + n + '\\b(?!Box)', 'g'), '$1' + n + 'Box.value')
          .replace(new RegExp('(mutating:\\s*)' + n + '\\b(?!Box)', 'g'), '$1' + n + 'Box.value')
          .replace(new RegExp('(start:\\s*)' + n + '\\b(?!Box)', 'g'), '$1' + n + 'Box.value')
          .replace(new RegExp('(runtime\\.pointee,\\s*)' + n + '\\b(?!Box)', 'g'), '$1' + n + 'Box.value');
      }
      lines[k] = l;
    }
    groups++;
    i = end;
  }
  if (groups === 0) return { text, status: 'nomatch' };
  let out = lines.join('\n');
  if (!out.endsWith('\n')) out += '\n';
  out += BOX_DEF;
  return { text: out, status: 'patched', groups };
}

const swiftFiles = findFile(pkgDir, 'JavaScriptRuntime.swift');
if (swiftFiles.length === 0) {
  console.log('[patch-expo-modules-jsi] JavaScriptRuntime.swift não encontrado; nada a fazer.');
}
for (const file of swiftFiles) {
  const original = fs.readFileSync(file, 'utf8');
  const r = patchRuntimeSwift(original);
  const rel = path.relative(root, file);
  if (r.status === 'patched') {
    fs.writeFileSync(file, r.text, 'utf8');
    changed++;
    console.log('[patch-expo-modules-jsi] corrigido: ' + rel + ' (' + r.groups + ' função(ões))');
  } else if (r.status === 'already') {
    console.log('[patch-expo-modules-jsi] já estava correto: ' + rel);
  } else {
    console.log('[patch-expo-modules-jsi] AVISO: padrão não encontrado em ' + rel +
      ' (versão do pacote diferente?). Nenhuma alteração feita nesse arquivo.');
  }
}

console.log('[patch-expo-modules-jsi] concluído (' + changed + ' arquivo(s) alterado(s)).');
